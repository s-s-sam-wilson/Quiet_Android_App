package com.example.quiet;

import static java.security.AccessController.getContext;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

public class Foreground extends Service {

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(0);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        String CHANNEL_ID = "Foreground service";

        //Notification
        NotificationChannel notificationChannel = new NotificationChannel(
                CHANNEL_ID,
                CHANNEL_ID,
                NotificationManager.IMPORTANCE_LOW
        );
        getSystemService(NotificationManager.class).createNotificationChannel(notificationChannel);
        Notification.Builder notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Quiet")
                .setContentText("Starting the Service")
                .setSmallIcon(R.drawable.add_a_heading);
        startForeground(1,notification.build());
        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        try{
                                fusedLocationProviderClient.requestLocationUpdates(locationRequest,
                                        new LocationCallback() {
                                            @Override
                                            public void onLocationResult(LocationResult locationResult) {
                                                Context context = getApplicationContext();

                                                // Get the current location
                                                Location location = locationResult.getLastLocation();

                                                // Check if the location is not null
                                                if (location != null) {
                                                    // Get the latitude and longitude of the location
                                                    double latitude = location.getLatitude();
                                                    double longitude = location.getLongitude();

                                                    // Set the message for the toast
                                                    CharSequence text = "Latitude: " + latitude + "\nLongitude: " + longitude;

                                                    // Set the duration for the toast
                                                    int duration = Toast.LENGTH_SHORT;

                                                    // Create the toast object

                                                    // Show the toast
                                                    notification.setContentText(text);
                                                    startForeground(1,notification.build());
                                                    //startService(serviceIntent);
                                                }
                                            }
                                        }, Looper.getMainLooper());
                            }catch (SecurityException se) {
                                se.printStackTrace();
                            }
                        }
                }
        ).start();
        return START_STICKY;
    }

}
